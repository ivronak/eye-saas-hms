IV Backup Agent
================

1. Upload this folder to your server (prefer outside public_html, or protect it).
2. Copy config.sample.php → config.php and paste project token from IV Backup panel.
3. Make storage/tmp writable (chmod 755/775).
4. In IV Backup panel → Projects → Add:
   - Agent URL: https://your-domain.com/iv-backup-agent/agent.php
   - Folder path: absolute path to site (e.g. /home/user/public_html/mysite)
5. Click Test / Run Now.

Requirements: PHP 8.1+, ZipArchive, mysqldump (only if DB backup enabled).
