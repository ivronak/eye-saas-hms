EYENOSIS — Google Play Store Listing Assets (v2 — real app screenshots)
=========================================================================

short_description.txt   (72 / 80 characters)
long_description.txt    (2350 / 4000 characters)

icon/
  icon-512x512.png       512x512 PNG — the eye_care_app's real launcher icon,
                          resized exactly to spec.

banner/
  feature-graphic-1024x500.png   1024x500 PNG, Play Store feature graphic.
                          This one is a marketing collage (brand colors/logo),
                          not a device screenshot — Play Store doesn't require
                          it to be an actual screen.

screenshots/ — REAL app screens, not mockups this time.
  screenshot-1-clinical-queue.png    Clinical Queue (Primary/Dilation/
                                     Secondary tabs, doctor assignments)
  screenshot-2-ot-ward-queue.png     OT Ward Entry Queue
  screenshot-3-medicines.png         Medicine Master catalogue

HOW these were made (so you know exactly what you're submitting):
  The eye_care_app Flutter source on this VPS was built for web
  (`flutter build web`) from small throwaway entry points that render the
  REAL screen widgets — the actual Dart classes used in the shipping app
  (AppBar, cards, colors, fonts, spacing — all real, pixel for pixel) — fed
  with realistic placeholder data instead of logging into a live hospital
  account. No login, no real patient data, no network calls were used.
  Captured at exactly 1080x1920 (9:16) via headless Chromium.

  This is NOT a native build, so there is a small chance of a minor
  rendering difference vs. a real Android/iOS device (font hinting,
  scrollbar style) — but every widget, color, and layout is the real app's
  own code, not a recreation. If Play Store review ever flags it, the
  safest fix is to swap in real screenshots taken from an actual device
  running the app.

  Only 3 screens were done this way (dashboard and the exam screen pull in
  much more internal state/tabs and would take a lot more time to mock
  safely) — Play Store requires a minimum of 2, so this already satisfies
  the requirement; more can be added the same way on request.
